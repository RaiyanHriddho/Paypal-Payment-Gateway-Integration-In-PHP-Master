<!DOCTYPE html>
<html>
    <head>
        <title> Paypal Payment Gateway Integration in PHP </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="css/paypal.css">
    </head>

    <div class="container">

    	<h2 style="text-align: center; color: blue;">Sorry !!</h2>

	    <div class="status">
	        <h1 class="error">Your PayPal Transaction has been Canceled.</h1>
	    </div>
	    <a href="index.php" class="btn-link">Back to Products</a>
	</div>

</html>